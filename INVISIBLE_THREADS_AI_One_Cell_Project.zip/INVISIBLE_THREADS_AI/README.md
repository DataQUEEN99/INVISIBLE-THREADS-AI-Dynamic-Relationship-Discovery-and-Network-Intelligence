# INVISIBLE THREADS AI
A one-cell Jupyter project for comparing statistical relationships across two datasets or conditions.

## Features
- Correlation matrices for both groups
- Ranked relationship changes
- Relationship drift heatmap
- Variable relationship networks
- Missingness summary and chart
- CSV exports

## Run
Open `INVISIBLE_THREADS_AI_One_Cell.ipynb` in Jupyter or Google Colab and run the single code cell.

## Your own CSV
Set `USE_CSV = True` and `CSV_PATH = "your_dataset.csv"`. If a `Condition` column exists, the first two distinct groups are compared. Otherwise, numeric rows are split in half, which is exploratory and may not represent meaningful conditions.

## Dependencies
numpy, pandas, matplotlib, networkx, scikit-learn

## Limitations
Correlations describe associations, not causation. Missing values are median-imputed for correlation calculations, and missingness is reported separately. Synthetic demo results are not real-world discoveries.
